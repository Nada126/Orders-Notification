package com.FCAI.OrdersAndNotifications.DTOS;

import lombok.Data;

@Data
public class LoginUser {
    private String email;
    private String password;
}

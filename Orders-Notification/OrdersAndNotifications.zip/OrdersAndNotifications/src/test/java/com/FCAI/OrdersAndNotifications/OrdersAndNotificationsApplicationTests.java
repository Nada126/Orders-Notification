package com.FCAI.OrdersAndNotifications;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdersAndNotificationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
